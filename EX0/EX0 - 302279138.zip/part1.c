#include <stdio.h>
#include <math.h>
#include <stdbool.h>


bool IsPowerOf2(int num) {
	if ((((num & (num - 1)) == 0) && (num > 0))){
		return true;
	}else{
		return false;
	}
}

int main () {

//choose screen to project outputs and error messeges--------------------------------
	setvbuf(stdout, NULL, _IONBF, 0);
	setvbuf(stderr, NULL, _IONBF, 0);
//scannig the size of input----------------------------------------------------------
	printf("Enter size of input:\n");
	int size_of_input;
	if ((scanf("%d",&size_of_input) != 1) || (size_of_input <= 0)) {   // FIXME: maybe long long int
		printf("Invalid size\n");
		return 0 ;
	}
//scanning all the inputs------------------------------------------------------------
	printf("Enter numbers:\n");
	int input_arr[size_of_input];
	int num , sum = 0 ;
	for (int i=0 ; i<size_of_input ; i++) {
		if (scanf("%d",&num) != 1){
			printf("Invalid number\n");
			return 0;
		}
		input_arr[i] = num;
	}
//printing number that are power of 2 and sumerize the exponents---------------------
		int exponent;
		int tmp;
		for (int i=0 ; i<size_of_input ; i++){
			tmp = input_arr[i];
			if (IsPowerOf2(tmp)) {
				exponent = (int)log2(tmp);
				sum = sum + exponent;
				printf("The number %d is a power of 2: %d = 2^%d\n" ,tmp,tmp,exponent);
			}
		}
	printf("Total exponent sum is %d\n" , (int)sum);
	return 0;
}
